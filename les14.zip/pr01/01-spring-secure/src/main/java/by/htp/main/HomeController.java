package by.htp.main;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}
	
	@RequestMapping("/services")
	public String service() {
		return "services";
	}

	@RequestMapping("/appointments")
	public String appointment() {
		return "appointments";
	}
	
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
}
